<?php
get_header();
?>

<div class="mainstage-show-content-div">
    <?php the_content(); ?>
</div>

<?php
get_footer();
?>