<?php get_header(); ?>

<div class="childrens-theatre-content-div">
    <?php the_content(); ?>
</div>

<?php get_footer(); ?>